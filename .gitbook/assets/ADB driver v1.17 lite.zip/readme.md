#Android USB UnifL

Among other projects, leshcatlabs.net is developing so called Android adb-USB UnifL Driver.

Those drivers are based on latest Google adb-USB Drivers and aimed to support wide range of Android devices.

Key benefits of adb-USB UnifL drivers as follows:

1. Latest Google adb-USB driver
2. Wide range of already supported non-Google Android devices.
3. Android adb-USB UnifL driver is using private certificate, that means you don’t have to enable “Test Mode“.

Website: http://leshcatlabs.net/android-usb-unifl/

Request to add new device(s): http://leshcatlabs.net/forums/viewtopic.php?f=15&t=603
 
